import numpy as np

arr = np.arange(1, 21).reshape(4, 5)
print(arr)

# Output:
# [[ 1  2  3  4  5]
#  [ 6  7  8  9 10]
#  [11 12 13 14 15]
#  [16 17 18 19 20]]